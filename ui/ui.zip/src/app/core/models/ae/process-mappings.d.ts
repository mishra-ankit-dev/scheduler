interface IAEPPMapping {
  [key: string]: string[];
}
