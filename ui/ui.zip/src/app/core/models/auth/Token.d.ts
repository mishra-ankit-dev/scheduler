// import { IUser } from './User';

interface IToken {
  user: IUser;
  key: string;
}
