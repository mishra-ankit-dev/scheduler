import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-gauge',
  templateUrl: './gauge.component.html',
  styleUrls: ['./gauge.component.scss'],
})
export class GaugeComponent implements OnInit {
  @Input('gaugeText') gaugeText: string = '';
  @Input('gaugeValue') gaugeValue: number = 0;

  constructor() {}

  ngOnInit(): void {}
}
