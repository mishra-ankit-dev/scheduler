import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { share, switchMap } from 'rxjs/operators';
import { CommonService } from 'src/app/core/services/site-layout/common.service';

@Component({
  selector: 'app-search-box',
  templateUrl: './search-box.component.html',
  styleUrls: ['./search-box.component.scss'],
})
export class SearchBoxComponent implements OnInit {
  constructor(private _commonService: CommonService) {}

  ngOnInit(): void {
    this._commonService.listenClicks$.pipe(
      switchMap(() => this._commonService.listen()),
      share()
    );
  }

  get placeholder$() {
    return this._commonService.placeholder$;
  }

  // get spokenKeywords$(): Observable<string> {
  //   return this._commonService.spokenKeywords$;
  // }

  // get searchBoxTypedKeywords$(): Observable<string> {
  //   return this._commonService.searchBoxQuery$;
  // }

  set searchBoxTypedKeywords(value: string) {
    this._commonService.searchBoxTypedKeywords = value;
  }

  // searchBoxKeywords$ = merge(
  //   this.spokenKeywords$,
  //   this.searchBoxTypedKeywords$
  // );

  get searchBoxKeywords$(): Observable<string> {
    return this._commonService.searchBoxKeywords$;
  }

  get listenClicks$(): Observable<string> {
    console.log(this._commonService.listenClicks$);
    return this._commonService.listenClicks$;
  }

  set listenClicks(value: string) {
    console.log('Button clicked....In SearchBox.ts');
    this._commonService.listenClicks = value;
  }
}
