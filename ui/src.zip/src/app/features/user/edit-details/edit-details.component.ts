import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

// All related to Forms
import { FormGroup } from '@angular/forms';
import { UserDetailsForms } from 'src/app/core/forms/auth/auth.form';
import { UserService } from 'src/app/core/services/auth/user.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { isValid, isInValid } from 'src/app/core/validators/custom.validator';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-edit-details',
  templateUrl: './edit-details.component.html',
  styleUrls: ['./edit-details.component.scss'],
})
export class EditDetailsComponent implements OnInit, OnDestroy {
  isValid = isValid;
  isInValid = isInValid;

  isUserConfirmed: boolean = false;
  loggedInUser: IUser = this._authData.loggedInUser;
  loggedInUser$: Observable<IUser> = this._authData.getLoggedInUser$();
  allUsers$: Observable<IUser[]> = this._authData.getAllUsers$();

  constructor(
    private _route: Router,
    private _auth: AuthService,
    private _authData: UserService
  ) {}

  confirmUserForm!: FormGroup;

  editDetailsForm: FormGroup = UserDetailsForms.EditDetailsForm(
    <IUser>{},
    <IUser[]>[]
  );
  userProfile$!: Observable<IProfile>;

  value_c(controlName: string) {
    return this.confirmUserForm.controls[controlName];
  }

  value_e(controlName: string) {
    return this.editDetailsForm.controls[controlName];
  }

  ngOnInit(): void {
    let temp = this._authData.getLoggedInUser$().pipe(
      switchMap((loggedInUser: IUser) => {
        this._authData.setLoggedInUser$(loggedInUser);
        this.loggedInUser = loggedInUser;
        this.confirmUserForm = UserDetailsForms.ConfirmUserForm(loggedInUser);
        this.allUsers$ = this._authData.GetAllUsers();
        this.userProfile$ = this._authData.getUserProfile$();
        this.allUsers$.pipe(
          switchMap((allUsers: IUser[]) => {
            console.log(allUsers);
            this.editDetailsForm = UserDetailsForms.EditDetailsForm(
              loggedInUser,
              allUsers
            );
            return of('');
          })
        );
        return of('');
      })
    );
    temp.subscribe();
  }

  confirmUser() {
    this.value_c('username').setValue(this.loggedInUser.username);
    this._auth.LogIn(this.confirmUserForm.value).subscribe(
      (logInResponse) => {
        localStorage.setItem('username', logInResponse.user.username);
        this.editDetailsForm.patchValue(logInResponse.user);
        this.isUserConfirmed = true;
      },

      (logInError) => {
        console.log(logInError);
        this.isUserConfirmed = false;
        alert(logInError);
      },

      () => {
        console.log('Confirmed User Successfully');
      }
    );
  }

  changeUserDetails() {
    this._auth.EditUserDetails(this.editDetailsForm.value).subscribe(
      (editUserDetailsResponse) => {
        console.log(editUserDetailsResponse);
        this._route.navigate(['']);
      },

      (editUserDetailsError) => {
        console.log(editUserDetailsError);
        alert(editUserDetailsError.error);
      },

      () => {
        console.log('Details edited Successfully');
      }
    );
  }

  ngOnDestroy() {
    // this.subscriptions.unsubscribe();
  }
}
