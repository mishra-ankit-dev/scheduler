import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

// All related to Forms
import { FormGroup } from '@angular/forms';
import { isValid, isInValid } from 'src/app/core/validators/custom.validator';
import { UserService } from 'src/app/core/services/auth/user.service';
import { UserForms } from 'src/app/core/forms/user/user.form';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss'],
})
export class EditProfileComponent implements OnInit, OnDestroy {
  isValid = isValid;
  isInValid = isInValid;
  loggedInUser: IUser = this._userService.loggedInUser;

  editProfileForm: FormGroup = UserForms.EditProfile(this.loggedInUser);

  value(controlName: string) {
    return this.editProfileForm.get(controlName);
  }

  constructor(private _userService: UserService, private _router: Router) {}

  ngOnInit(): void {
    this.setUserProfile();
  }

  setUserProfile() {
    this._userService.getUserProfile$().subscribe((profileResponse) => {
      console.log(profileResponse);
      profileResponse ? delete profileResponse.image : {};
      this.editProfileForm.patchValue(profileResponse);
    });
  }

  editProfile() {
    this.editProfileForm.removeControl('image');
    console.log(this.editProfileForm.value);
    this._userService.EditProfile(this.editProfileForm.value).subscribe(
      (editProfileResponse) => {
        console.log(editProfileResponse);
        this._userService.setUserProfile$(editProfileResponse);
        this._router.navigate(['']);
      },
      (editProfileError) => {
        console.log(editProfileError);
      },
      () => {
        console.log('Edit profile Service called Successfully');
      }
    );
  }

  ngOnDestroy() {
    // this.subscriptions.unsubscribe();
  }
}
