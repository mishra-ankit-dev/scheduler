import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-monitor',
  templateUrl: './health-monitor.component.html',
  styleUrls: ['./health-monitor.component.scss']
})
export class HealthMonitorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
