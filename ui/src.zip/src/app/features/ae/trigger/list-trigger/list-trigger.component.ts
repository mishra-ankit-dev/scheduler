import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TriggersService } from 'src/app/core/services/ae/triggers.service';

@Component({
  selector: 'app-list-trigger',
  templateUrl: './list-trigger.component.html',
  styleUrls: ['./list-trigger.component.scss'],
})
export class ListTriggerComponent implements OnInit {
  allTriggers$!: Observable<IAETrigger[]>;

  constructor(private _triggerService: TriggersService) {}

  ngOnInit(): void {
    this.allTriggers$ = this._triggerService.GetAllTriggers();
  }

  onTriggerDelete(_: IAETrigger) {
    this.ngOnInit();
  }
}
