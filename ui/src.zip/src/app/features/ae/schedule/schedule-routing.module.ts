import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateScheduleComponent } from './create-schedule/create-schedule.component';
import { ViewAllSchedulesComponent } from './view-all-schedules/view-all-schedules.component';

const schedulerRoutes: Routes = [
  { path: '', redirectTo: 'view/all', pathMatch: 'full' },
  { path: 'create', component: CreateScheduleComponent },
  {
    path: 'view/:filter',
    component: ViewAllSchedulesComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(schedulerRoutes)],
  exports: [RouterModule],
})
export class ScheduleRoutingModule {}
