import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { CommonService } from 'src/app/core/services/site-layout/common.service';
import { ServersService } from 'src/app/core/services/ae/servers.service';
import { RouteNames } from 'src/app/core/constants/route.names';

@Component({
  selector: 'app-view-all-servers',
  templateUrl: './view-all-servers.component.html',
  styleUrls: ['./view-all-servers.component.scss'],
})
export class ViewAllServersComponent implements OnInit, OnDestroy {
  allServers$!: Observable<IAEServer[]>;

  deleteServerSubs!: Subscription;
  allFilteredServers$!: Observable<IAEServer[]>;

  serverStatus: string = '';

  constructor(
    private _router: Router,
    private _commonService: CommonService,
    private _serverService: ServersService
  ) {}

  ngOnInit(): void {
    this.allServers$ = this._serverService.GetAllServers$();
  }

  ViewServer(server: IAEServer) {
    this._serverService.selectedServer = server;
    this._router.navigate([
      RouteNames.getRoutePathByName('server-home'),
      server.serverName,
      'view',
    ]);
  }

  EditServer(server: IAEServer) {
    this._serverService.selectedServer = server;
    this._router.navigate([
      RouteNames.getRoutePathByName('server-home'),
      server.serverName,
      'edit',
    ]);
  }

  DeleteServer(server: IAEServer) {
    if (
      confirm(
        `Do you want to delete the Server with name ${server.serverName} ?\n
This will delete all the entities using this server i.e Triggers, Schedules, Executions, etc.`
      )
    ) {
      this.deleteServerSubs = this._serverService
        .DeleteServer(server.serverName)
        .subscribe(
          (_) => {
            this.allServers$ = this._serverService.GetAllServers$();
            this._router.navigate([
              RouteNames.getRoutePathByName('server-view-all'),
            ]);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  StartServer(server: IAEServer) {
    if (
      confirm(
        `Do you want to ${
          server.status ? 'stop' : 'start'
        } the Server with name ${server.serverName} ?`
      )
    ) {
      this.serverStatus = 'Changing for ' + server.serverName;
      this.deleteServerSubs = this._serverService
        .StartServer(server.serverName)
        .subscribe(
          (_) => {
            this.allServers$ = this._serverService.GetAllServers$();
            this.serverStatus = 'Changed';
          },
          (err) => {
            console.log(err);
            this.serverStatus = '';
          },
          () => {
            this._router.navigate([
              RouteNames.getRoutePathByName('server-view-all'),
            ]);
          }
        );
    }
  }

  ngOnDestroy() {
    this._commonService.searchBoxTypedKeywords = '';
    if (this.deleteServerSubs) {
      this.deleteServerSubs.unsubscribe();
    }
  }
}
