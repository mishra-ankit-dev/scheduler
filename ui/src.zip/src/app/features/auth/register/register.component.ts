import { Observable, Subscription, timer } from 'rxjs';
import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

// All related to Forms
import { FormGroup } from '@angular/forms';
import { AuthenticationForms } from 'src/app/core/forms/auth/auth.form';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { isValid, isInValid } from 'src/app/core/validators/custom.validator';
import { UserService } from 'src/app/core/services/auth/user.service';
import { map, share, switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit, OnDestroy {
  isValid = isValid;
  isInValid = isInValid;

  notification: INotification = <INotification>{};
  allUsers$!: Observable<IUser[]>;

  signUpForm: FormGroup = AuthenticationForms.SignUpForm(<IUser[]>[]);
  allUsersFetchSubs!: Subscription;

  value(controlName: string) {
    return this.signUpForm.controls[controlName];
  }

  constructor(
    private _auth: AuthService,
    public _userService: UserService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.allUsersFetchSubs = timer(0, 20000)
      .pipe(
        switchMap((_) => this._userService.allUsers$),
        map((allUsers: IUser[]) => this._userService.setAllUsers$(allUsers)),
        share()
      )
      .subscribe();

    this.allUsers$ = this._userService.getAllUsers$();

    this.allUsers$.subscribe((allUsers: IUser[]) => {
      this.signUpForm = AuthenticationForms.SignUpForm(allUsers);
    });
  }

  signUp() {
    this._auth.Register(this.signUpForm.value).subscribe((signUpResponse) => {
      localStorage.setItem('Token', signUpResponse.key);
      alert(
        'Hit the link sent to ' +
          signUpResponse.user.email +
          ' to activate acount'
      );

      this._router.navigate(['/auth']);
    });
  }

  ngOnDestroy() {
    // this.subscriptions.unsubscribe();
    if (this.allUsersFetchSubs) {
      this.allUsersFetchSubs.unsubscribe();
    }
  }
}
