import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription, combineLatest, of } from 'rxjs';
import { switchMap, share } from 'rxjs/operators';
import { CommonService } from 'src/app/core/services/site-layout/common.service';
import { SchedulesService } from 'src/app/core/services/uipath/schedules.service';
import { RouteNames } from 'src/app/core/constants/route.names';

@Component({
  selector: 'app-pending-schedules',
  templateUrl: './pending-schedules.component.html',
  styleUrls: ['./pending-schedules.component.scss'],
})
export class PendingSchedulesComponent implements OnInit {
  constructor(
    private _router: Router,
    private _commonService: CommonService,
    private _schedulesService: SchedulesService
  ) {}

  deleteScheduleSubs!: Subscription;
  allPendingSchedules$!: Observable<IUiPathSchedule[]>;
  allFilteredSchedules$!: Observable<IUiPathSchedule[]>;

  ngOnInit() {
    this.allPendingSchedules$ = this._schedulesService.GetAllPendingSchedules();

    this.allFilteredSchedules$ = combineLatest([
      this.allPendingSchedules$,
      this._commonService.searchBoxKeywords$,
    ]).pipe(
      switchMap(([schedules, keyword]) => {
        return <Observable<IUiPathSchedule[]>>(
          this._commonService.ProcessKeywords(
            keyword,
            schedules,
            (): Observable<IUiPathSchedule[]> => {
              let filteredScheduleList: IUiPathSchedule[] = [];
              if (keyword == '') {
                return of(schedules);
              } else {
                schedules.forEach((schedule: IUiPathSchedule) => {
                  const scheduleValues = Object.values(schedule);
                  for (var index in scheduleValues) {
                    const scheduleValue =
                      scheduleValues[index] == null
                        ? ''
                        : scheduleValues[index];
                    if (
                      scheduleValue
                        .toString()
                        .toUpperCase()
                        .includes(keyword.toUpperCase())
                    ) {
                      filteredScheduleList.push(schedule);
                      break;
                    }
                  }
                });
                return of(filteredScheduleList);
              }
            }
          )
        );
      }),
      share()
    );
  }

  DeleteSchedule(schedule: IUiPathSchedule) {
    if (
      confirm(
        `Do you want to delete the Schedule with name ${schedule.scheduleName} ?\n
This will delete all the entities using this schedule i.e Execution, etc.`
      )
    ) {
      this.deleteScheduleSubs = this._schedulesService
        .DeleteSchedule(schedule.id)
        .subscribe(
          (_) => {
            this.allPendingSchedules$ =
              this._schedulesService.GetAllSchedules();
            this._router.navigate([
              RouteNames.getRoutePathByName('schedule-view-all'),
            ]);
          },
          (err) => {
            console.log(err);
            alert(err.message);
          }
        );
    }
  }

  ngOnDestroy() {
    this._commonService.searchBoxTypedKeywords = '';
    if (this.deleteScheduleSubs) {
      this.deleteScheduleSubs.unsubscribe();
    }
  }
}
