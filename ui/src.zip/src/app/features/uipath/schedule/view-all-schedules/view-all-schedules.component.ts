import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { SchedulesService } from 'src/app/core/services/uipath/schedules.service';
import { RouteNames } from 'src/app/core/constants/route.names';

@Component({
  selector: 'app-view-all-schedules',
  templateUrl: './view-all-schedules.component.html',
  styleUrls: ['./view-all-schedules.component.scss'],
})
export class ViewAllSchedulesComponent implements OnInit, OnDestroy {
  filter!: string;
  deleteScheduleSubs!: Subscription;
  allSchedules$!: Observable<IUiPathSchedule[]>;
  allFilteredSchedules$!: Observable<IUiPathSchedule[]>;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _schedulesService: SchedulesService
  ) {
    this._route.params.subscribe((params) => {
      this.filter = params.filter;
      this.allSchedules$ = this._schedulesService.GetAllSchedules(this.filter);
    });
  }

  ngOnInit() {}

  DeleteSchedule(schedule: IUiPathSchedule) {
    if (
      confirm(
        `Do you want to delete the Schedule with name ${schedule.scheduleName} ?\n
This will delete all the entities using this schedule i.e Execution, etc.`
      )
    ) {
      this.deleteScheduleSubs = this._schedulesService
        .DeleteSchedule(schedule.id)
        .subscribe((_) => {
          this.allSchedules$ = this._schedulesService.GetAllSchedules(
            this.filter
          );
          this._router.navigate([
            RouteNames.getRoutePathByName('schedule-view'),
            this.filter,
          ]);
        });
    }
  }

  ngOnDestroy() {
    if (this.deleteScheduleSubs) {
      this.deleteScheduleSubs.unsubscribe();
    }
  }
}
