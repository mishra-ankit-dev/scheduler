import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TriggerRoutingModule } from './trigger-routing.module';
import { CreateTriggerComponent } from './create-trigger/create-trigger.component';
import { ViewAllTriggersComponent } from './view-all-triggers/view-all-triggers.component';
import { ViewOrEditTriggerComponent } from './view-or-edit-trigger/view-or-edit-trigger.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { RouterModule } from '@angular/router';
import { CommonService } from 'src/app/core/services/site-layout/common.service';

@NgModule({
  declarations: [
    CreateTriggerComponent,
    ViewOrEditTriggerComponent,
    ViewAllTriggersComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    TriggerRoutingModule,
    SharedModule,
  ],
  exports: [RouterModule],
})
export class TriggerModule {}
