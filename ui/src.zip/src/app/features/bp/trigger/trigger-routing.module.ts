import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateTriggerComponent } from './create-trigger/create-trigger.component';
import { ViewAllTriggersComponent } from './view-all-triggers/view-all-triggers.component';
import { ViewOrEditTriggerComponent } from './view-or-edit-trigger/view-or-edit-trigger.component';

const triggerRoutes: Routes = [
  { path: '', redirectTo: 'view-all', pathMatch: 'full' },
  {
    path: 'create',
    component: CreateTriggerComponent,
  },
  {
    path: ':id/:mode',
    component: ViewOrEditTriggerComponent,
  },
  {
    path: 'view-all',
    component: ViewAllTriggersComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(triggerRoutes)],
  exports: [RouterModule],
})
export class TriggerRoutingModule {}
