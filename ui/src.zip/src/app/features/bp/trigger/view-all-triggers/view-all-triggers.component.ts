import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { combineLatest, Observable, of, Subscription } from 'rxjs';
import { share, switchMap } from 'rxjs/operators';
import { CommonService } from 'src/app/core/services/site-layout/common.service';
import { TriggersService } from 'src/app/core/services/bp/triggers.service';
import { SchedulesService } from 'src/app/core/services/bp/schedules.service';
import { RouteNames } from 'src/app/core/constants/route.names';

@Component({
  selector: 'app-view-all-triggers',
  templateUrl: './view-all-triggers.component.html',
  styleUrls: ['./view-all-triggers.component.scss'],
})
export class ViewAllTriggersComponent implements OnInit, OnDestroy {
  allTriggers$!: Observable<IBPTrigger[]>;
  deleteTriggerSubs!: Subscription;
  allFilteredTriggers$!: Observable<IBPTrigger[]>;
  addScheduleSubs!: Subscription;

  constructor(
    private _triggersService: TriggersService,
    private _commonService: CommonService,
    private _router: Router,
    private _schedulesService: SchedulesService
  ) {}

  ngOnInit() {
    this.allTriggers$ = this._triggersService.GetAllTriggers();
  }

  EditTrigger(triggerData: IBPTrigger) {
    this._triggersService.trigger = triggerData;
    this._router.navigate([
      RouteNames.getRoutePathByName('trigger-home'),
      triggerData.id,
      'edit',
    ]);
  }

  ViewTrigger(triggerData: IBPTrigger) {
    this._triggersService.trigger = triggerData;
    this._router.navigate([
      RouteNames.getRoutePathByName('trigger-home'),
      triggerData.id,
      'view',
    ]);
  }

  DeleteTrigger(trigger: IBPTrigger) {
    if (
      confirm(
        `Do you want to delete the Trigger with name ${trigger.triggerName} ?\n
This will delete all the entities using this trigger i.e Schedules, Execution, etc.`
      )
    ) {
      this.deleteTriggerSubs = this._triggersService
        .DeleteTrigger(trigger.id)
        .subscribe(
          (_) => {
            this.allTriggers$ = this._triggersService.GetAllTriggers();
            this._router.navigate([
              RouteNames.getRoutePathByName('trigger-view-all'),
            ]);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  ExecuteTrigger(trigger: IBPTrigger) {
    const instantSchedule: IBPSchedule = {
      id: 0,
      status: '',
      occurOnceDateTime: null,
      recurringEndDate: null,
      recurringStartDate: null,
      recurringTime: null,
      recurringType: 'Now',
      scheduleName: 'Now',
      trigger: trigger.id,
      userName: (<IUser>(
        JSON.parse(sessionStorage.getItem('userToken') || '').user
      )).username,
    };
    this.addScheduleSubs = this._schedulesService
      .AddSchedule(instantSchedule)
      .subscribe(
        (_) => {
          this._router.navigate([
            RouteNames.getRoutePathByName('schedule-view'),
            'all',
          ]);
        },
        (err) => {
          console.log(err);
          alert(err.message);
        }
      );
  }

  ngOnDestroy() {
    this._commonService.searchBoxTypedKeywords = '';
    if (this.deleteTriggerSubs) {
      this.deleteTriggerSubs.unsubscribe();
    }
    if (this.addScheduleSubs) {
      this.addScheduleSubs.unsubscribe();
    }
  }
}
