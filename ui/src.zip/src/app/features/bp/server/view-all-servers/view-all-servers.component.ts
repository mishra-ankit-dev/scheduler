import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { combineLatest, Observable, of, Subscription } from 'rxjs';
import { share, switchMap } from 'rxjs/operators';
import { CommonService } from 'src/app/core/services/site-layout/common.service';
import { ServersService } from 'src/app/core/services/bp/servers.service';
import { RouteNames } from 'src/app/core/constants/route.names';

@Component({
  selector: 'app-view-all-servers',
  templateUrl: './view-all-servers.component.html',
  styleUrls: ['./view-all-servers.component.scss'],
})
export class ViewAllServersComponent implements OnInit, OnDestroy {
  allServers$!: Observable<IBPServer[]>;

  deleteServerSubs!: Subscription;
  allFilteredServers$!: Observable<IBPServer[]>;

  serverStatus: string = '';

  constructor(
    private _commonService: CommonService,
    private _serverService: ServersService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.allServers$ = this._serverService.GetAllServers$();
    // this.allFilteredServers$ = combineLatest([
    //   (this.allServers$ = this._serverService.GetAllServers$()),
    //   this._commonService.searchBoxKeywords$,
    // ]).pipe(
    //   switchMap(([servers, keyword]) => {
    //     return <Observable<IBPServer[]>>this._commonService.ProcessKeywords(
    //       keyword,
    //       servers,
    //       (): Observable<IBPServer[]> => {
    //         let filteredServerList: IBPServer[] = [];
    //         if (keyword == '') {
    //           return of(servers);
    //         } else {
    //           servers.forEach((server: IBPServer) => {
    //             const serverValues = Object.values(server);
    //             for (var index in serverValues) {
    //               const serverValue =
    //                 serverValues[index] == null ? '' : serverValues[index];
    //               if (
    //                 serverValue
    //                   .toString()
    //                   .toUpperCase()
    //                   .includes(keyword.toUpperCase())
    //               ) {
    //                 filteredServerList.push(server);
    //                 break;
    //               }
    //             }
    //           });
    //           return of(filteredServerList);
    //         }
    //       }
    //     );
    //   }),
    //   share()
    // );
  }

  ViewServer(server: IBPServer) {
    this._serverService.selectedServer = server;
    this._router.navigate([
      RouteNames.getRoutePathByName('server-home'),
      server.serverName,
      'view',
    ]);
  }

  EditServer(server: IBPServer) {
    this._serverService.selectedServer = server;
    this._router.navigate([
      RouteNames.getRoutePathByName('server-home'),
      server.serverName,
      'edit',
    ]);
  }

  DeleteServer(server: IBPServer) {
    if (
      confirm(
        `Do you want to delete the Server with name ${server.serverName} ?\n
This will delete all the entities using this server i.e Triggers, Schedules, Executions, etc.`
      )
    ) {
      this.deleteServerSubs = this._serverService
        .DeleteServer(server.serverName)
        .subscribe(
          (_) => {
            this.allServers$ = this._serverService.GetAllServers$();
            this._router.navigate([
              RouteNames.getRoutePathByName('server-view-all'),
            ]);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  StartServer(server: IBPServer) {
    if (
      confirm(
        `Do you want to ${
          server.status ? 'stop' : 'start'
        } the Server with name ${server.serverName} ?`
      )
    ) {
      this.serverStatus = 'Changing for ' + server.serverName;
      this.deleteServerSubs = this._serverService
        .StartServer(server.serverName)
        .subscribe(
          (_) => {
            this.allServers$ = this._serverService.GetAllServers$();
            this.serverStatus = 'Changed';
          },
          (err) => {
            console.log(err);
            this.serverStatus = '';
          },
          () => {
            this._router.navigate([
              RouteNames.getRoutePathByName('server-view-all'),
            ]);
          }
        );
    }
  }

  ngOnDestroy() {
    this._commonService.searchBoxTypedKeywords = '';
    if (this.deleteServerSubs) {
      this.deleteServerSubs.unsubscribe();
    }
  }
}
