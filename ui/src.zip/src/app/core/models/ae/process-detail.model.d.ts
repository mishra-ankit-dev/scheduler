interface IAEProcessDetail {
  processName: string;
  version: string;
  processInputs: string[];
}
