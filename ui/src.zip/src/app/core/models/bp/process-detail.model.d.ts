interface IBPProcessDetail {
  processName: string;
  version: string;
  processInputs: string[];
}
