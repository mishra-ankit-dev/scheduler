interface IBPPPMapping {
  [key: string]: string[];
}
