interface IUiPathPPMapping {
  [key: string]: string[];
}
