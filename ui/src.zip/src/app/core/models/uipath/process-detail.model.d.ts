interface IUiPathProcessDetail {
  releaseKey: string;
  version: string;
  processName: string;
  tenancyName: string;
  processInputs: string[];
}
