import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { share, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SpeechService {
  speechRecognition: any;
  private _spokenKeywords$!: Observable<string>;

  // Subject for Search Box
  public _listenClicksSubject$ = new Subject<string>();
  private _listenClicks$ = this._listenClicksSubject$.asObservable();

  get listenClicks$(): Observable<string> {
    return this._listenClicks$;
  }
  set listenClicks(value: string) {
    this._listenClicksSubject$.next(value);
  }

  constructor() {
    this.createSpeechRegognitionObject();

    // countinously check if mic is pressed if yes, start listening
    this._spokenKeywords$ = this._listenClicks$.pipe(
      switchMap(() => this.listen()),
      share()
    );
  }

  get spokenKeywords$(): Observable<string> {
    return this._spokenKeywords$;
  }

  createSpeechRegognitionObject() {
    const { webkitSpeechRecognition } = window as any;
    this.speechRecognition = new webkitSpeechRecognition();
  }

  listen(): Observable<string> {
    console.log('Started Listening with : ' + this.speechRecognition);
    return new Observable<string>((observer) => {
      console.log('Started Listening....');

      const resultHandler = (speechRecognitionObj: any) => {
        console.log(speechRecognitionObj);
        const speech: string = this.getTranscript(speechRecognitionObj.results);
        console.log(speech);
        observer.next(speech);
        observer.complete();
      };

      const errorHandler = (err: any) => {
        observer.error(err);
      };

      this.speechRecognition.addEventListener('result', resultHandler);
      this.speechRecognition.addEventListener('error', errorHandler);
      this.speechRecognition.start();

      return () => {
        this.speechRecognition.removeEventListener('result', resultHandler);
        this.speechRecognition.removeEventListener('error', errorHandler);
        this.speechRecognition.abort();
      };
    });
  }

  getTranscript(results: { transcript: string }[][]): string {
    return results[0][0].transcript;
  }
}
