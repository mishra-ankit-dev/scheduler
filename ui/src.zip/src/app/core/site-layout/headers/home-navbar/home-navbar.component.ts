import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { UserService } from 'src/app/core/services/auth/user.service';
import { TechnologyDataService } from 'src/app/core/services/technology-data.service';

@Component({
  selector: 'app-home-navbar',
  templateUrl: './home-navbar.component.html',
  styleUrls: ['./home-navbar.component.scss'],
})
export class HomeNavbarComponent implements OnInit {
  @Input('titleColored') titleColored!: string;
  @Input('titleUnColored') titleUnColored!: string;

  loggedInUser$!: Observable<IUser>;
  userProfile$!: Observable<IProfile>;

  constructor(
    private _userService: UserService,
    private _technologyDataService: TechnologyDataService
  ) {}

  ngOnInit(): void {
    this.loggedInUser$ = this._userService.getLoggedInUser$().pipe(
      tap((loggedInUser: IUser) => {
        this.userProfile$ = this._userService.GetUserProfileById(
          loggedInUser.id
        );
      })
    );
  }

  // SetTechnology(technology: string) {
  //   this._technologyDataService.currentTechnology = technology;
  // }
}
