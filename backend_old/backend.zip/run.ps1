C:\.monitor\venv\Scripts\activate.ps1
cd C:\.monitor\backend 
python manage.py runserver 0.0.0.0:8000