from django.apps import AppConfig


class AeConfig(AppConfig):
    name = 'features.ae.api'
