from django.apps import AppConfig


class AeConfig(AppConfig):
    name = 'features.bp.api'
    label = 'bp_api'
